<?php


// prinst_r($_SERVER['QUERY_STRING']);

$size = $_REQUEST['size'];
$url = "https://i.ebayimg.com/00/s/";
$url .= $_REQUEST['url']."/";

$image = "";

// echo $image = $_REQUEST['image']."</br />";

if($size == "n") // Normal Image 800x800
	$image = "\$_3.JPG";
elseif($size =="b") // Big Image
	$image = "\$_57.JPG";
elseif($size =="t") // Thumb Image
	$image = "\$_7.JPG";



$pic = $url.$image;

if($size=="images")
	$pic = "https://i.ebayimg.com/images/".$_REQUEST['url'].".jpg";


// echo $pic;

$image = (file_get_contents($pic));


// Set the content type header - in this case image/jpeg
header('Content-Type: image/jpeg');

echo $image;

?>