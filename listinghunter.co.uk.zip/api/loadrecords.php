<?php
	$searchkey = $_REQUEST['searchkey'];

	$currentPage = isset($_REQUEST['currentPage'])?$_REQUEST['currentPage']:"1";

	$dir = isset($_REQUEST['dir'])?$_REQUEST['dir']:"";


	$categoryId = isset($_REQUEST['categoryId'])?$_REQUEST['categoryId']:-1;
	// print_r($_REQUEST);

	

	$jsonurl = "https://svcs.ebay.com/services/search/FindingService/v1?OPERATION-NAME=findItemsAdvanced&SERVICE-VERSION=1.13.0&SECURITY-APPNAME=TritecGr-VisualSe-PRD-6c8ec878c-a9b17a7b&RESPONSE-DATA-FORMAT=JSON&REST-PAYLOAD&GLOBAL-ID=EBAY-GB&keywords=".urlencode($searchkey)."&paginationInput.pageNumber=".$currentPage;

	if($categoryId>0)
		$jsonurl = "https://svcs.ebay.com/services/search/FindingService/v1?OPERATION-NAME=findItemsAdvanced&SERVICE-VERSION=1.13.0&SECURITY-APPNAME=TritecGr-VisualSe-PRD-6c8ec878c-a9b17a7b&RESPONSE-DATA-FORMAT=JSON&REST-PAYLOAD&GLOBAL-ID=EBAY-GB&categoryId=".$categoryId."&paginationInput.pageNumber=".$currentPage;

	$jsonurl .= "&itemFilter(0).name=HideDuplicateItems&itemFilter(0).value=true";

	$jsonurl .= "&outputSelector(0)=PictureURLLarge";
 	$jsonurl .= "&outputSelector(1)=PictureURLSuperSize";
 	$jsonurl .= "&outputSelector(2)=GalleryInfo";

 	
	

	function seoUrl($string) {
	    //Lower case everything
	    $string =  strtolower($string);
	    //Make alphanumeric (removes all other characters)
	    $string = preg_replace("/[^a-z0-9_\s-]/", "", $string);
	    //Clean up multiple dashes or whitespaces
	    $string = preg_replace("/[\s-]+/", " ", $string);
	    //Convert whitespaces and underscore to dash
	    $string = preg_replace("/[\s_]/", "-", $string);
	    return $string;
	}


		$json = file_get_contents($jsonurl);
		$ebay_response_data = (json_decode($json));

		$ebay_response_data = $ebay_response_data->findItemsAdvancedResponse[0];

		// print_r($ebay_response_data->ack[0]);

		// echo "<pre>";
		// print_r($resp);


		if($currentPage<=1)
			echo '<div class="resultcount">'.number_format($ebay_response_data->paginationOutput[0]->totalEntries[0]).' results </div>';
			echo '<ul class="main-record-list items list-unstyled">';

		// Check to see if the call was successful, else print an error
		if ($ebay_response_data->ack[0] == "Success") {
		  $results = '';  // Initialize the $results variable

			
		  	// Parse the desired information from the response
		  	foreach($ebay_response_data->searchResult[0]->item as $item) {
		    	
		    	$id = $item->itemId[0];

		    	$title = $item->title[0];

		    	$image_title = seoUrl($title);
		    	// $pic   = $item->pictureURLLarge[0];


		    	// $pic = "http://thumbs.ebaystatic.com/d/l300/pict/".$id."_1.JPG";

		    	$pic = $dir."d/l300/pict/".$id."/".$image_title.".JPG";

		    	//$pic   = $item->pictureURLSuperSize[0];
		    	// $pic   = $item->pictureURL[0];
		    	// $pic   = $item->galleryURL[0];
		    	// $pic   = $item->galleryPlusPictureURL[0];
		    	$link  = $item->viewItemURL[0];
		    	

		    	//echo "<pre>";
		    	//print_r($item->sellingStatus[0]->currentPrice[0]->__value__);

		    	$price = $item->sellingStatus[0]->currentPrice[0]->__value__;
		    	$timeleft =  $item->sellingStatus[0]->timeLeft[0];
		    	$timeleft = new DateInterval($timeleft);


		    	// echo $timeleft->d . ' days and ' . $timeleft->h . ' hours';


		    	$href_link = $dir."item/".$image_title."-".$id.".html";

		    	?>
		    	<li id="item-<?php echo $id; ?>">
					<div class="shadow"></div>
					<a target="_blank" href="<?php echo $href_link; ?>" title="<?php echo $title; ?>">
						<div class="sq">
							<img class="lazy" src="<?php echo $pic; ?>"  alt="<?php echo $title; ?>">
							

							<!--div class="controls" onmouseenter="slideEnable(this)" onmouseleave="slideDisable(this)">
								<span class="thumbnum" onclick="thumbnext(this, arguments[0]);return false;">
									<span class="current">1</span>/8</span>

								<span class="glyphicon glyphicon-triangle-left" aria-hidden="true" onclick="thumbprev(this, arguments[0]);return false;"></span>
								<span class="glyphicon glyphicon-triangle-right" aria-hidden="true" onclick="thumbnext(this, arguments[0]);return false;"></span>
							</div-->
						</div>
						<h3><?php echo $title; ?></h3>
					</a>
					<div class="price">
						<strong>£<?php echo $price; ?></strong> 
						<small>Buy It Now</small> 
						<small class="timeleft text-danger"><strong><?php echo $timeleft->d."d ".$timeleft->h."h"; ?></strong></small>
					</div>
					<div class="button">
						<a target="_blank" href="<?php echo $link; ?>">
							<button class="btn btn-primary btn-xs" onclick="" rel="nofollow">
								<span class="glyphicon glyphicon-arrow-right" aria-hidden="true"></span> 
								See Details
							</button>
						</a>
					</div>
				</li>
		    	<?php
		  	}
		}

		// echo $results;

		if($currentPage<=1)
			echo '</ul>';

		
?>
