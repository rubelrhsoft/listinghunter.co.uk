
	<?php

	$page = "category";
	$rootCategoryName = $categoryName;


	$jsonurl = "http://open.api.ebay.com/Shopping?callname=GetCategoryInfo&appid=TritecGr-VisualSe-PRD-6c8ec878c-a9b17a7b&responseencoding=JSON&siteid=3&CategoryID=-1&version=729&IncludeSelector=ChildCategories";



	$json = file_get_contents($jsonurl);
	$ebayAllCategories = json_decode($json,true);
	$ebayAllCategories = $ebayAllCategories['CategoryArray']['Category'];

	$currentCategory = null;



	

	foreach ($ebayAllCategories as $category) {
		if(seoUrl($category['CategoryName']) == $categoryName){
			$currentCategory = $category;
			break;
		}
	}


	$jsonurl = "http://open.api.ebay.com/Shopping?callname=GetCategoryInfo&appid=TritecGr-VisualSe-PRD-6c8ec878c-a9b17a7b&responseencoding=JSON&siteid=3";

	$jsonurl .= "&CategoryID=".$currentCategory['CategoryID']."&version=729&IncludeSelector=ChildCategories";
	$json = file_get_contents($jsonurl);
	$childCategories = json_decode($json,true);
	$childCategories = $childCategories['CategoryArray']['Category'];

	if(isset($_REQUEST['category2'])){
		$categoryName = $_REQUEST['category2'];

		foreach ($childCategories as $category) {
			if(seoUrl($category['CategoryName']) == $categoryName){
				$currentCategory = $category;
				break;
			}
		}

		
	}

	?>

	<div class="container-fluid main-content">

		<div class="sub-menu">
			<ul id="sub-menu">
		      <li class="nav-item category-sub" style="list-style: none;">
		       	  <h4><?php echo $currentCategory['CategoryName']; ?></h4>
		          <ul class="nav clearfix">
		          		<?php
		          		foreach($childCategories as $ebayCategory){
		          			if($ebayCategory['CategoryParentID']>0){
		          				$seoCategory = seoUrl($ebayCategory['CategoryName']);

		          				echo '<li style="float:left;" class="nav-item ';
		          				echo ($categoryName==$seoCategory)?" active":"";
		          				echo '">
						              <a class="nav-link" href="'.$dir.$rootCategoryName."/".$seoCategory.'/">'.$ebayCategory['CategoryName'].'</a>
						            </li>';
		          			}
		          		}
		          		?>
		          </ul>
		      </li>

		      
		      
		    </ul>
		</div>

		<hr />
		<div class="clear"></div>

		<?php
			// echo "<pre>";
			// echo $categoryName;
			// print_r($currentCategory); // CategoryID
			// print_r($childCategories);

		?>



		<div class="main-area loading-center">

			<div class="load-wrapp">
	            <div class="load-5">
	                <div class="ring-2">
	                	<span class="badge badge-danger" style="margin-top: 7px;">100</span>
	                    <div class="ball-holder">
	                        <div class="ball"></div>
	                    </div>
	                </div>
	            </div>
	        </div>

    	</div>

    	<div class="clear"></div>

    	<?php //include('options-menu.php'); 
    	$searchkey = "cars";
    	?>

    	<script type="text/javascript">registercallapi("<?php echo $searchkey; ?>","<?php echo $dir; ?>","<?php echo $currentCategory['CategoryID']; ?>");</script>

		<?php
		

		?>
	</div>
			

	