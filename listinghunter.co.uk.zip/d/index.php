<?php
$args = explode('/', $_SERVER['QUERY_STRING']);
//print_r($_SERVER['QUERY_STRING']);

$size = $_REQUEST['size'];
$id = $_REQUEST['id'];
$title = $_REQUEST['title'];

$pic = "http://thumbs.ebaystatic.com/d/".$size."/pict/".$id."_1.JPG";

$image = (file_get_contents($pic));


// Set the content type header - in this case image/jpeg
header('Content-Type: image/jpeg');

echo $image;

?>