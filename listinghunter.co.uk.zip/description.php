<?php

$id = $_REQUEST['id'];


$jsonurl = "https://open.api.ebay.com/shopping?callname=GetSingleItem&responseencoding=JSON&appid=TritecGr-VisualSe-PRD-6c8ec878c-a9b17a7b&siteid=3&version=967&ItemID=".$id;

$jsonurl .= "&IncludeSelector=Description";


$json = file_get_contents($jsonurl);
$ebay_single_data = json_decode($json,true);

echo $ebay_single_data["Item"]["Description"];

?>