<div class="footer">
		<div class="container-fluid">
			
			<ul class="footer-menu">
			<li><a href="#">Privacy Policy</a></li>
			<li><a href="#">Terms and Conditions</a></li>
			<li><a href="#">Contact Us</a></li>
			
			</ul>
			<div style="clear: both"></div>
			<p class="text-center">
				Copyright &copy; 2019-2020 ListingHunter. All Rights Reserved.<br>
			</p>
		</div>
</div>


	


	</body>
</html>