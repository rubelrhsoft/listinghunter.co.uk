<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
	<link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300&display=swap" rel="stylesheet"> 
	<link href="https://fonts.googleapis.com/css2?family=Raleway:wght@500;700&display=swap" rel="stylesheet">
	<script src="<?php echo $dir; ?>js/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.4.1/js/bootstrap.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/typeahead.js/0.10.5/typeahead.bundle.min.js"></script>
	<script src="<?php echo $dir; ?>js/yall.min.js"></script>
	<script src="<?php echo $dir; ?>js/script.js"></script>
	<script src="<?php echo $dir; ?>js/menu-script.js"></script>
	<link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.4.1/css/bootstrap.min.css" rel="stylesheet" />
	<link href="<?php echo $dir; ?>css/style.css" rel="stylesheet" />
	<link href="<?php echo $dir; ?>css/prebook.css" rel="stylesheet" />

	<title>ListingHunter • Search eBay Faster</title>
	<meta property="og:title" content="ListingHunter • Search eBay Faster" />
	<meta property="og:site_name" content="ListingHunter" />
</head>
<body>	

	<?php
	$searchkey = "";

	$menu_category = "";

	if(isset($_REQUEST['category']))
		$menu_category = $_REQUEST['category'];

	if(isset($_REQUEST['q'])) $searchkey = $_REQUEST['q'];

	$jsonurl = "http://open.api.ebay.com/Shopping?callname=GetCategoryInfo&appid=TritecGr-VisualSe-PRD-6c8ec878c-a9b17a7b&responseencoding=JSON&siteid=3&CategoryID=-1&version=729&IncludeSelector=ChildCategories";

	$json = file_get_contents($jsonurl);
	$ebayAllCategories = json_decode($json,true);
	$ebayAllCategories = $ebayAllCategories['CategoryArray']['Category'];

	function seoUrl($string) {
	    //Lower case everything
	    // $string =  strtolower($string);
	    //Make alphanumeric (removes all other characters)
	    $string = preg_replace("/[^A-Za-z0-9_\s-]/", "", $string);
	    //Clean up multiple dashes or whitespaces
	    $string = preg_replace("/[\s-]+/", " ", $string);
	    //Convert whitespaces and underscore to dash
	    $string = preg_replace("/[\s_]/", "-", $string);
	    return $string;
	}
	
	?>	
<div class="header-bg">
<div class="container">
	<div class="row">
		<div class="slider-text">
			<div class="logo">
			<a href="index.php"><img src="images/logo.png" alt="logo"></a>
			<i class="fa fa-facebook-square" aria-hidden="true"></i>

			</div>
		<h1>Welcome to Listing Hunter</h1>
		<h3>Visual Ebay Search Engine Tool<br/></br/>Changing the way you discover new products</h3>
		</div>
		<div class="search-box">
		<form id="search" class="navbar-form" action="<?php echo $dir; ?>" role="search">
				<div class="form-group">
					<label class="sr-only" for="q">Search </label>
					<input type="text" id="q" name="q" class="form-control empty typeahead" tabindex="1" placeholder="Search eBay Faster" value="<?php echo $searchkey; ?>" autocapitalize="off" autocorrect="off" spellcheck="false" autocomplete="off" />
				</div>
				<button type="submit" class="btn btn-link search" title="Search"><span class="sr-only">Search</span><span class="glyphicon glyphicon-search" aria-hidden="true"></span></button>
				
			</form>
			<h5>Search over 120milion live Ebay listings now with our Visual Search Engine Tool</h5>
		</div>
		<div class="home-banner">
		
		<div class="banner-title">HEY, DID YOU KNOW...</div>
		<div class="banner-text">
<p>We use intelligent algorithms to bring you<br/>
products from different marketplaces</p>
<p>Reseach suggests the human brain processes<br/>
images 60,000 times faster than text.</p>
<p>Our visual search engine enables you to find<br/>
many more products at once compared to<br/>
traditional markplace search results.</p>

		</div>
		
		</div>
	</div>
</div>
	
	<nav class="navbar navbar-default navbar-fixed-top">	
	<div class="collapse navbar-toggleable-xs clearfix" id="collapsing-navbar">
	    <ul class="nav navbar-nav clearfix">
	      <!-- <li class="nav-item">
	        <a class="nav-link" data-toggle="collapse" href="#collapseHome" aria-expanded="false" aria-controls="collapseHome">Home</a>
	        <span class="collapse subnav-container" id="collapseHome">
	        </span>
	      </li> -->
	      <li class="nav-item">
	        <a class="nav-link" data-toggle="collapse" href="#collapseCategories" aria-expanded="false" aria-controls="collapseCategories">eBay Categories</a>
	        <span class="collapse subnav-container" id="collapseCategories">            
	          <ul class="nav clearfix">
	          		<?php
	          		foreach($ebayAllCategories as $ebayCategory){
	          			if($ebayCategory['CategoryID']>0){
	          				$seoCategory = seoUrl($ebayCategory['CategoryName']);
	          				echo '<li class="nav-item';
	          				echo ($menu_category==$seoCategory)?" active":"";
	          				echo '">
					              <a class="nav-link" href="'.$dir.$seoCategory.'/">'.$ebayCategory['CategoryName'].'</a>
					            </li>';
	          			}
	          		}
	          		?>
	          </ul>
	        </span>
	      </li>

	      <!-- <li class="nav-item">
	        <a class="nav-link" data-toggle="collapse" href="#collapseAbout" aria-expanded="false" aria-controls="collapseAbout">About ListingHunter</a>
	        <span class="collapse subnav-container" id="collapseAbout">            
	          
	        </span>
	      </li> -->
	      
	    </ul>
	    <!-- Remove in if no active submenu -->
	    <div class="collapse in" id="spaceman">
	      <div id="spaceman-inner"></div>
	      
	    </div>
	  </div>

		<div class="clear"></div>
	</nav>
</div>

	<div class="clear"></div>