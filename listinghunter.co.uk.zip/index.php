
	<?php

	$page = "home";



	$dir = "";

	if(isset($_REQUEST['category'])){
		$page = "category";
		$dir = "../";
	}

	if(isset($_REQUEST['category2'])){
		$dir = "../../";
	}

	if(isset($_REQUEST['category3'])){
		$dir = "../../../";
	}

	include('header.php');




	if($searchkey){
	?>
	<div class="container-fluid main-content">

		<div class="main-area loading-center">

			<div class="load-wrapp">
	            <div class="load-5">
	                <div class="ring-2">
	                	<span class="badge badge-danger" style="margin-top: 7px;">100</span>
	                    <div class="ball-holder">
	                        <div class="ball"></div>
	                    </div>
	                </div>
	            </div>
	        </div>

    	</div>

    	<div class="clear"></div>

    	<?php //include('options-menu.php'); ?>

    	<script type="text/javascript">registercallapi("<?php echo $searchkey; ?>");</script>

		<?php
		

		?>
	</div>

	<?php

	} else if($page == "home"){
	?>

	<div class="container-fluid">
		<div class="row">
			<div class="main-content">
				<div class="col-sm-8">
					<h3 class="title-entry">About Us</h3>
					<p>We are a young startup company based in the in the UK. Wirral Our mission is to help you find products from marketplaces more easily and faster than ever before.</p>
					<p>We have developed a search engine that instead of being restricted to the front user interface og Ebay. you can instead get straight into the products and important details that you are looking for.</p>
					<br/>
					<h3>Our Future</h3>
					<p>We search all the internet and are looking to add more than Ebay to our search engine. Soon there will be Esty, Amazon and unique small boutique retailers.</p>

	<p>Listing Hunter is quickly expanding with Denmark and USA search engines launching fully very soon.</p>
				</div>
				<div class="col-sm-4 banner-left">
				<div class="thumbnail"><img src="images/about-us.jpg" alt="about-us"></div>	
				
				</div>
				<div style="clear: both"></div>
				<div class="col-sm-2 searchman">
				
				<img src="images/searchman.png" alt="searchman">
				</div>
				<div class="col-sm-10">
				<h3>Disclaimers:</h3>

				<p>View our terms and conditions, Privacy Poilicy, Contact us</p>
				
				</div>
				
			
			</div>
			
		</div>

	</div>


	<?php
	}

	else if($page == "category"){
		$categoryName = $_REQUEST['category'];
		include('category.php');
	}

	include('footer.php');
	?>
			

	