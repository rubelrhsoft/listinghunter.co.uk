<?php

// $args = explode('/', $_SERVER['QUERY_STRING']);
print_r($_SERVER['QUERY_STRING']);

// Main Item Id
$id = $_REQUEST['id'];

$id = str_replace('.html','',$id);


// URL for cathing single item details
$jsonurl = "https://open.api.ebay.com/shopping?callname=GetSingleItem&responseencoding=JSON&appid=TritecGr-VisualSe-PRD-6c8ec878c-a9b17a7b&siteid=3&version=967&ItemID=".$id;

$jsonurl .= "&IncludeSelector=Description,ItemSpecifics,ShippingCosts,Details,Variations";

ehco $jsonurl;

$json = file_get_contents($jsonurl);
$ebay_single_data = json_decode($json,true);


?>

<?php
	$dir ="../";
	include('../header.php');
?>
	
	
	<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700" rel="stylesheet">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.css" />
	<script src="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.js"></script>

	<link href="../css/product.css" rel="stylesheet" />

	<div class="container product">
		<div class="card">
			<div class="container-fliud">
				<div class="wrapper row">
					

					<div class="details col-md-6">
						<h3 class="product-title"><?php echo $ebay_single_data["Item"]["Title"]; ?></h3>
						<div class="price">

							<i class="glyphicon glyphicon-tag"></i> <span class="big">£<?php echo $ebay_single_data["Item"]["ConvertedCurrentPrice"]["Value"];?></span> <span class="small">(<?php echo $ebay_single_data["Item"]["ListingType"]; ?>)</span>

							<?php
								$timeleft =  $ebay_single_data["Item"]["TimeLeft"];
			    				$timeleft = new DateInterval($timeleft);


							?>

							<small class="timeleft text-danger">
								<strong><?php echo $timeleft->d."d ".$timeleft->h."h"; ?></strong>

							</small>

							<small>, <?php echo $ebay_single_data["Item"]["ReturnPolicy"]["ReturnsWithin"]; ?> Return </small>

						</div>
						
						<div class="seller">
							<i class="glyphicon glyphicon-eye-open"></i> <?php echo $ebay_single_data["Item"]["HitCount"];  ?> views 
							<br /><br />
							<div>
								<div class="title">Seller: <b><?php echo $ebay_single_data["Item"]["Seller"]['UserID'];  ?></b></div>
								<div id="rating1" class="rating"></div>
								<script type="text/javascript">
									rating(<?php echo $ebay_single_data["Item"]["Seller"]['PositiveFeedbackPercent'];  ?>);
								</script>
								
							</div>
							<div class="vote">
								<strong><?php echo $ebay_single_data["Item"]["Seller"]['PositiveFeedbackPercent'];  ?>%</strong> of buyers enjoyed this product! (<strong><?php echo $ebay_single_data["Item"]["Seller"]['FeedbackScore'];  ?> </strong> Feedback Score) <br />
								<strong><i class="glyphicon glyphicon-map-marker"></i> Location: </strong><?php echo $ebay_single_data["Item"]["Location"];  ?>
								

							</div>
							
						</div>
						
						
						
						<ul class="itemSpecifics">

						<?php
							$itemSpecifics = $ebay_single_data["Item"]["ItemSpecifics"]["NameValueList"];
							foreach ($itemSpecifics as &$itemSpecific) {
								echo "<li><b>".$itemSpecific['Name'].":</b> ".$itemSpecific['Value'][0]."</li>";

							}
						?>

						</ul>
						



						


						


						
					</div>

					<div class="preview col-md-6">
						
						<div class="preview-pic tab-content">

							<?php 

							function seoUrl($string) {
							    //Lower case everything
							    $string =  strtolower($string);
							    //Make alphanumeric (removes all other characters)
							    $string = preg_replace("/[^a-z0-9_\s-]/", "", $string);
							    //Clean up multiple dashes or whitespaces
							    $string = preg_replace("/[\s-]+/", " ", $string);
							    //Convert whitespaces and underscore to dash
							    $string = preg_replace("/[\s_]/", "-", $string);
							    return $string;
							}


								$pictures = $ebay_single_data["Item"]["PictureURL"];
								$i = 1;
								foreach ($pictures as $picture) {

									// Normal Slide Pic and Zoomed pic linking here
									// 2 types of image urls we got from ebay product page
									// 1 - 00/ starting
									// 2 - images/ starting

									if(strpos($picture, "https://i.ebayimg.com/00/s/") !== false ){
											$picture = str_replace("https://i.ebayimg.com/00/s/", "", $picture);

											$picurl = substr($picture, 0, strrpos( $picture, '/'));
											$picurl .= "/".seoUrl($ebay_single_data["Item"]["Title"])."_".$i.".jpg";

											echo '<div class="tab-pane ';
											if($i==1) echo "active";
											echo '" id="pic-'.$i.'"><a data-fancybox="gallery" href="../00/b/'.$picurl.'"><img title="'.$ebay_single_data["Item"]["Title"].'" src="../00/n/'.$picurl.'" /></a></div>';
										}
									else{
											$picture = str_replace("https://i.ebayimg.com/images/", "", $picture);

											$picurl = substr($picture, 0, strrpos( $picture, '.'));
											$picurl .= "/".seoUrl($ebay_single_data["Item"]["Title"])."_".$i.".jpg";


											echo '<div class="tab-pane ';
											if($i==1) echo "active";
											echo '" id="pic-'.$i.'"><a data-fancybox="gallery" href="../00/images/'.$picurl.'"><img title="'.$ebay_single_data["Item"]["Title"].'" src="../00/images/'.$picurl.'" /></a></div>';
									}

								


									
								    $i++;

								}
							?>
						  
						  	<div class="searchcompass right">
								<img src="../images/searchcompass.png" />
							</div>

						</div>
						<ul class="preview-thumbnail nav nav-tabs">

							<?php
								$i=1;
								foreach ($pictures as $picture) {

									// Thumbnail Pics linking here
									// We use low res pics for thumbs here in order to make loading faster for the page
									// 2 types of image urls we got from ebay product page
									// 1 - 00/ starting
									// 2 - images/ starting

									if(strpos($picture, "https://i.ebayimg.com/00/s/") !== false ){
										$picture = str_replace("https://i.ebayimg.com/00/s/", "", $picture);

										$picurl = substr($picture, 0, strrpos( $picture, '/'));
										$picurl .= "/".seoUrl($ebay_single_data["Item"]["Title"])."_".$i.".jpg";

										echo '<li class="';
										if($i==1) echo "active";
										echo '">';
										echo '<a data-target="#pic-'.$i.'" data-toggle="tab">';
										echo '<img src="../00/t/'.$picurl.'" /></a></li>';
									}
									else{
										$picture = str_replace("https://i.ebayimg.com/images/", "", $picture);

										$picurl = substr($picture, 0, strrpos( $picture, '.'));
										$picurl .= "/".seoUrl($ebay_single_data["Item"]["Title"])."_".$i.".jpg";
										echo '<li class="';
										if($i==1) echo "active";
										echo '">';
										echo '<a data-target="#pic-'.$i.'" data-toggle="tab">';
										echo '<img src="../00/images/'.$picurl.'" /></a></li>';
									}
								    $i++;
								}
							?>
						  
						</ul>
						
					</div>



					
				</div>

				<div class="row center">
					<div class="action">
						
						<a target="_blank" href="https://www.ebay.co.uk/itm/<?php echo $ebay_single_data['Item']['ItemID']; ?>">
						<button class="add-to-cart btn btn-default" type="button"><i class="glyphicon glyphicon-open"></i> See Details on eBay</button></a>
						<button class="like btn btn-default" type="button"><span class="fa fa-heart"></span></button>
					</div>
				</div>

				<div class="row">
					

					<div class="product-description">


						<?php
						$plain_description = strip_tags($ebay_single_data["Item"]["Description"]);
						?>
						<strong><i class="glyphicon glyphicon-info-sign"></i> Description :</strong>

						<div class="short">
							<?php 

							// Description limiting 1000 chars
							echo strlen($plain_description) >= 1000 ? 
								substr($plain_description, 0, 990) . ' <a class="read_more">[Read more]</a>' : 
								$plain_description;
							?>

						</div>
						<div class="long">

							
							
							<iframe id="description_iframe" style="border: 0; width: 100%;" src="<?php echo $dir.'description.php?id='.$id; ?>" scrolling="no" onload=""></iframe>

							<script type="text/javascript">

								document.getElementById('description_iframe').style.height=$(document.getElementById('description_iframe').contentWindow.document).height()+2+"px";
								
								document.getElementById('description_iframe').onload = function() {
								 
								  this.style.height=$(this.contentWindow.document).height()+2+"px";
								};
								

							</script>
							
							
							<a class="hide_more">[Hide more]</a>
						</div>
					</div>
				</div>
			</div>

			
			<div class="searchman left">
				<img src="../images/searchman.png" />
				<h3 class="title">Here's what I found....</h3>
			</div>
		</div>

		
	</div>
  


  <?php
	include('../footer.php');

	// echo "<pre>";
	// print_r($ebay_single_data);
	// echo "</pre>";
	?>


