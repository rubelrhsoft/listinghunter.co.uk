
var currentPage = 1;		// Current Page Counter 
var loadingNode = "";		// Loading Animation HTML Node
var searchkey = "";			// The main search keyword(s)
var loadingPage = false;	// Is Loading/Api Calling running or not
var SITEID = 3;				// GB | UK Store
var inDir = "";				// Directory Reverse of the calling page | for category home/category-page/
var inCategory = "";		// If Category page then it will have value



var substringMatcher = function(strs) {
  return function findMatches(q, cb) {
    var matches, substringRegex;

    // an array that will be populated with substring matches
    matches = [];

    // regex used to determine if a string contains the substring `q`
    substrRegex = new RegExp(q, 'i');

    // iterate through the pool of strings and for any string that
    // contains the substring `q`, add it to the `matches` array
    $.each(strs, function(i, str) {
      if (substrRegex.test(str)) {
        matches.push(str);
      }
    });

    cb(matches);
  };
};


/**
function for making the rating stars accurate
**/
function rating( stars ) {
	var cw = $(".rating").outerWidth(); // save original 100% pixel width
  	$(".rating").width(Math.round(cw * (stars / 100)) + 'px');
}

var keysimilar = new Bloodhound({
	datumTokenizer:Bloodhound.tokenizers.obj.whitespace('value'),
	queryTokenizer:Bloodhound.tokenizers.whitespace,
	limit:20,
	remote:{
		url:'https://autosug.ebay.com/autosug?kwd=%QUERY&_jgr=1&sId='+SITEID+'&_ch=0',
		ajax:{dataType:'jsonp'},
		filter:function(data){
			var keysimilar = [];
			var recentkeyfounds = (typeof localStorage!=='undefined' && localStorage.getItem('recentkeyfounds')!==null) ? JSON.parse(localStorage.getItem('recentkeyfounds')) : [];
			keysimilar = $.merge(keysimilar, $.map(recentkeyfounds, function(value){return (data.prefix=='' || (data.prefix!='' && (value.toLowerCase().indexOf(data.prefix.toLowerCase())==0 || value.toLowerCase().indexOf(' '+data.prefix.toLowerCase())!=-1))) ? {value:value, recent:true} : null;}));
			if(typeof data.recser!=='undefined')
				keysimilar = $.merge(keysimilar, $.map(data.recser.sug, function(value){return ($.inArray(value['kwd'], recentkeyfounds)==-1) ? {value:value['kwd']} : null;}));
			keysimilar = keysimilar.slice(0, (data.prefix=='') ? 20 : 3);
			
			recentnum = keysimilar.length;

			if(typeof data.res!=='undefined')
			{
				keysimilar = $.merge(keysimilar, $.map(data.res.sug, function(value){return {value:value};}));
				
			}
			return keysimilar;
		}
	}
});
keysimilar.initialize();


/**
DOM Ready Function | Main Entry Point
**/
$( document ).ready(function() {

	// Yall Added for Lazy / Asynchronous Loading of all the images
	document.addEventListener("DOMContentLoaded", yall);

	

	// Keyword keysimilar added typeahead plugin
	$('#search .typeahead').typeahead({
	  hint: false,
	  highlight: true,
	  minLength: 0,
	  typeaheadMinLength: 0,
	  showHintOnFocus: true,
	  // on click list option set as text value
      autoSelect: true
	},
	{
	  name: 'keysimilar',
	  source: keysimilar.ttAdapter(),
	  displayKey:'value'
		
	}).on('typeahead:selected', function(ev, suggestion){
		$('#search').submit();
	}).on('click',function(){
		if($('.tt-dropdown-menu').css('display')=='none'){ev=$.Event('keydown');ev.keyCode=ev.which=40;$(this).trigger(ev);}
	});


	// Fix problem with autosuggestion selected if mouse around that area
	$('#search .typeahead').on('keyup', function(ev){
		if(ev.which!==38 && ev.which!==40)
		{
			$('.tt-cursor').removeClass('tt-cursor');
			setTimeout(function(){
				$('.tt-cursor').removeClass('tt-cursor');
			}, 200);
			setTimeout(function(){
				$('.tt-cursor').removeClass('tt-cursor');
			}, 300);
			setTimeout(function(){
				$('.tt-cursor').removeClass('tt-cursor');
			}, 400);
		}
	});


	

	// Read More Click Function added for Product Display Page
	$("a.read_more").click(function(){
		$(".product-description .short").hide();
		$(".product-description .long").show();

		document.getElementById('description_iframe').style.height=$(document.getElementById('description_iframe').contentWindow.document).height()+2+"px";
	});

	// Hide More Click Function added for Product Display Page
	$("a.hide_more").click(function(){
		$(".product-description .short").show();
		$(".product-description .long").hide();
	});

	// Window Scroll added specially to detect end of the page and load new listing
	$(window).bind('scroll', function() {

		try{

		    if(loadingPage == false && $(window).scrollTop() >= $('.main-area').offset().top + $('.main-area').outerHeight() - window.innerHeight) {
		        currentPage++;
		        loadpagerecords();
		        loadingPage = true;
		        // alert(currentPage);
		    }
		}catch(error){}
	});

	loadingNode = $(".load-wrapp");
});


/** First Ajax function to register the API call to eBay
 	* inSearchkey : searchable keywords parameter supplied from the frontend 
 **/
function registercallapi(inSearchkey,dir="",categoryId=""){
	searchkey = inSearchkey;
	inDir = dir;
	inCategory = categoryId;

	$.ajax({
	  method: "POST",
	  url: dir+"api/loadrecords.php",
	  data: { searchkey: searchkey,dir:dir, categoryId:categoryId }
	})
	  .done(function( msg ) {
	    $(".main-area").html(msg);
	  })
	  .fail(function(error) {
    	alert( "error"+error );
  	});
}

/** Load the eBay next round of data and apend to the end of the page **/
function loadpagerecords(){

	$(".main-area").append(loadingNode);

	$.ajax({
	  method: "POST",
	  url: inDir+"api/loadrecords.php",
	  data: { searchkey: searchkey, currentPage: currentPage, dir:inDir, categoryId:inCategory }
	})
	  .done(function( msg ) {
	    loadingNode.remove();
	    $(".main-record-list").append(msg);

	    // alert(msg);

	    loadingPage = false;
	  })
	  .fail(function(error) {
    	alert( "error"+error );
  	});
}


// https://alvarotrigo.com/blog/move-cursor-to-the-end-of-input-or-textarea/ with Ryan modification to plain javascript
function moveCursorToEnd(el)
{
	var originalValue = el.value;
	el.value = '';
	el.blur();
	el.focus();
	el.value = originalValue;
}